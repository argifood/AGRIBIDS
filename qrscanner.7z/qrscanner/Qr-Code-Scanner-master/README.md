# Android qr code scanner

### Description
 Full stable QR code scanner in android.

### Functionality 
 User can:
 * use flashlight 
 * search in the internet with scanned qr code value
 * copy to clipboard qr code value
 * share qr code value
 * see own history of scanned qr codes

### Screenshots 
![2017-11-23 11 27 00](https://user-images.githubusercontent.com/33349723/33159841-4de6736c-d041-11e7-8dc6-70c63be768e9.png)
